using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Commerce.Common;

namespace Commerce.Modules
{
    public class SendNotificationModule : ICommerceModule
    {
        public void Initialize(CommerceEvents events, NameValueCollection config)
        {
            events.SendNotification += OnSendNotification;
        }

        void OnSendNotification(SendNotificationEventArgs e)
        {
            e.Mailer.SendInvoiceEmail(e.OrderData);
        }
    }
}
