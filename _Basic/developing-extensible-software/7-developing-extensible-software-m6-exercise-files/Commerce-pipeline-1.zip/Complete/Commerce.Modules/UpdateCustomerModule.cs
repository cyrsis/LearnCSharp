using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Commerce.Common;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Modules
{
    public class UpdateCustomerModule : ICommerceModule
    {
        public void Initialize(CommerceEvents events, NameValueCollection config)
        {
            events.UpdateCustomer += OnUpdateCustomer;
        }
        void OnUpdateCustomer(UpdateCustomerEventArgs e)
        {
            foreach (OrderLineItemData lineItem in e.OrderData.LineItems)
            {
                for (int i = 0; i < lineItem.Quantity; i++)
                    e.Customer.Purchases.Add(new PurchasedItem() { Sku = lineItem.Sku, PurchasePrice = lineItem.PurchasePrice, PurchasedOn = DateTime.Now });
                Console.WriteLine("Added {0} unit(s) or product {1} to customer's purchase history.", lineItem.Quantity, lineItem.Sku);
            }
        }
    }
}
