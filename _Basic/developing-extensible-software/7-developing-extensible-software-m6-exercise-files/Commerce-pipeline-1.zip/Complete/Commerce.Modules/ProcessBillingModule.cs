using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Commerce.Common;
using Commerce.Common.DataModels;

namespace Commerce.Modules
{
    public class ProcessBillingModule : ICommerceModule
    {
        public void Initialize(CommerceEvents events, NameValueCollection config)
        {
            events.ProcessBilling += OnProcessBilling;
        }

        void OnProcessBilling(ProcessBillingEventArgs e)
        {
            double amount = 0;
            foreach (OrderLineItemData lineItem in e.OrderData.LineItems)
                amount += (lineItem.PurchasePrice * lineItem.Quantity);
            bool paymentSuccess = e.PaymentProcessor.ProcessCreditCard(e.Customer.Name, e.OrderData.CreditCard, e.OrderData.ExpirationDate, amount);
            if (!paymentSuccess)
                throw new ApplicationException(string.Format("Credit card {0} could not be processed.", e.OrderData.CreditCard));
        }
    }
}
