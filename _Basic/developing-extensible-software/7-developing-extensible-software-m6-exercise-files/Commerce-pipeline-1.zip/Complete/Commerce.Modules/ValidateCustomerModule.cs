﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Commerce.Common;
using Commerce.Common.Entities;

namespace Commerce.Modules
{
    public class ValidateCustomerModule : ICommerceModule
    {
        public void Initialize(CommerceEvents events, NameValueCollection config)
        {
            events.ValidateCustomer += OnValidateCustomer;
        }
        void OnValidateCustomer(ValidateCustomerEventArgs e)
        {
            Customer customer = e.StoreRepository.GetCustomerByEmail(e.OrderData.CustomerEmail);
            if (customer == null)
                throw new ApplicationException(string.Format("No customer on file with email {0}.", e.OrderData.CustomerEmail));

            e.Customer = customer;
        }
    }
}
