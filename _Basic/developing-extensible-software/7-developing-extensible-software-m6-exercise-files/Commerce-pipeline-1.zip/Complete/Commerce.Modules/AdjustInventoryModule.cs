using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Commerce.Common;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Modules
{
    public class AdjustInventoryModule : ICommerceModule
    {
        public void Initialize(CommerceEvents events, NameValueCollection config)
        {
            events.AdjustInventory += OnAdjustInventory;
        }
        
        void OnAdjustInventory(AdjustInventoryEventArgs e)
        {
            foreach (OrderLineItemData lineItem in e.OrderData.LineItems)
            {
                // process added order line item modules
                if (e.Events.OrderItemProcessed != null)
                {
                    OrderItemProcessedEventArgs args = new OrderItemProcessedEventArgs(e.Customer, lineItem);
                    e.Events.OrderItemProcessed(args);
                    if (args.Cancel)
                        throw new ApplicationException(args.MessageText);
                }

                Product product = e.StoreRepository.Products.Where(item => item.Sku == lineItem.Sku).FirstOrDefault();
                if (product == null)
                    throw new ApplicationException(string.Format("Sku {0} not found in store inventory.", lineItem.Sku));

                Inventory inventoryOnHand = e.StoreRepository.ProductInventory.Where(item => item.Sku == lineItem.Sku).FirstOrDefault();
                if (inventoryOnHand == null)
                    throw new ApplicationException(string.Format("Error attempting to determine on-hand inventory quantity for product {0}.", lineItem.Sku));

                if (inventoryOnHand.QuantityInStock < lineItem.Quantity)
                    throw new ApplicationException(string.Format("Not enough quantity on-hand to satisfy product {0} purchase of {1} units.", lineItem.Sku, lineItem.Quantity));

                inventoryOnHand.QuantityInStock -= lineItem.Quantity;
                Console.WriteLine("Inventory for product {0} reduced by {1} units.", lineItem.Sku, lineItem.Quantity);
            }
        }
    }
}
