﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Commerce.Common;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;
using Commerce.Engine.Contracts;

namespace Commerce.Engine
{
    public class CommerceManager : ICommerceManager
    {
        public CommerceManager(IStoreRepository storeRepository, IConfigurationFactory configurationFactory)
        {
            _StoreRepository = storeRepository;
            
            // load providers
            _PaymentProcessor = configurationFactory.GetPaymentProcessor();
            _Mailer = configurationFactory.GetMailer();
            _Events = configurationFactory.GetEvents();
        }

        IStoreRepository _StoreRepository;
        IPaymentProcessor _PaymentProcessor;
        IMailer _Mailer;
        CommerceEvents _Events;
        
        #region ICommerceManager Members

        public void ProcessOrder(OrderData orderData)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    Customer customer = null;

                    if (_Events.ValidateCustomer != null)
                    {
                        ValidateCustomerEventArgs args = new ValidateCustomerEventArgs(_StoreRepository, orderData);
                        _Events.ValidateCustomer(args);
                        customer = args.Customer;
                    }

                    if (_Events.AdjustInventory != null)
                    {
                        AdjustInventoryEventArgs args = new AdjustInventoryEventArgs(_StoreRepository, orderData, customer, _Events);
                        _Events.AdjustInventory(args);
                    }

                    if (_Events.UpdateCustomer != null)
                    {
                        UpdateCustomerEventArgs args = new UpdateCustomerEventArgs(_StoreRepository, customer, orderData);
                        _Events.UpdateCustomer(args);
                    }

                    if (_Events.ProcessBilling != null)
                    {
                        ProcessBillingEventArgs args = new ProcessBillingEventArgs(_StoreRepository, _PaymentProcessor, customer, orderData);
                        _Events.ProcessBilling(args);
                    }

                    if (_Events.SendNotification != null)
                    {
                        SendNotificationEventArgs args = new SendNotificationEventArgs(_Mailer, customer, orderData);
                        _Events.SendNotification(args);
                    }

                    scope.Complete();
                }
            }
            catch (Exception)
            {
                _Mailer.SendRejectionEmail(orderData);
                throw;
            }
        }

        #endregion
    }
}
