﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Commerce.Common
{
    public class CommerceEvents
    {
        public CommerceModuleDelegate<ValidateCustomerEventArgs> ValidateCustomer { get; set; }
        public CommerceModuleDelegate<ProcessBillingEventArgs> ProcessBilling { get; set; }
        public CommerceModuleDelegate<AdjustInventoryEventArgs> AdjustInventory { get; set; }
        public CommerceModuleDelegate<UpdateCustomerEventArgs> UpdateCustomer { get; set; }
        public CommerceModuleDelegate<SendNotificationEventArgs> SendNotification { get; set; }
        public CommerceModuleDelegate<OrderItemProcessedEventArgs> OrderItemProcessed { get; set; }
    }
}
