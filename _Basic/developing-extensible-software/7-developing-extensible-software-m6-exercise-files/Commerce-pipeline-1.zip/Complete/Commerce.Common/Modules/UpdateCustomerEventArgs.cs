using System;
using System.Collections.Generic;
using System.Linq;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Common
{
    public class UpdateCustomerEventArgs : EventArgs
    {
        public UpdateCustomerEventArgs(IStoreRepository storeRepository, Customer customer, OrderData orderData)
        {
            StoreRepository = storeRepository;
            Customer = customer;
            OrderData = orderData;
        }

        public IStoreRepository StoreRepository { get; set; }
        public Customer Customer { get; set; }
        public OrderData OrderData { get; set; }
    }
}
