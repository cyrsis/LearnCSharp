using System;
using System.Collections.Generic;
using System.Linq;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Common
{
    public class ProcessBillingEventArgs : EventArgs
    {
        public ProcessBillingEventArgs(IStoreRepository storeRepository, IPaymentProcessor paymentProcessor, Customer customer, OrderData orderData)
        {
            StoreRepository = storeRepository;
            PaymentProcessor = paymentProcessor;
            Customer = customer;
            OrderData = orderData;
        }

        public IStoreRepository StoreRepository { get; set; }
        public IPaymentProcessor PaymentProcessor { get; set; }
        public Customer Customer { get; set; }
        public OrderData OrderData { get; set; }
    }
}
