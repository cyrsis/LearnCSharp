using System;
using System.Collections.Generic;
using System.Linq;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Common
{
    public class ValidateCustomerEventArgs : EventArgs
    {
        public ValidateCustomerEventArgs(IStoreRepository storeRepository, OrderData orderData)
        {
            StoreRepository = storeRepository;
            OrderData = orderData;
        }

        public IStoreRepository StoreRepository { get; set; }
        public Customer Customer { get; set; }
        public OrderData OrderData { get; set; }
    }
}
