using System;
using System.Collections.Generic;
using System.Linq;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Common
{
    public class AdjustInventoryEventArgs : EventArgs
    {
        public AdjustInventoryEventArgs(IStoreRepository storeRepository, OrderData orderData, Customer customer, CommerceEvents events)
        {
            StoreRepository = storeRepository;
            OrderData = orderData;
            Customer = customer;
            Events = events;
        }

        public IStoreRepository StoreRepository { get; set; }
        public OrderData OrderData { get; set; }
        public Customer Customer { get; set; }
        public CommerceEvents Events { get; set; }
    }
}
