using System;
using System.Collections.Generic;
using System.Linq;
using Commerce.Common.Contracts;
using Commerce.Common.DataModels;
using Commerce.Common.Entities;

namespace Commerce.Common
{
    public class SendNotificationEventArgs : EventArgs
    {
        public SendNotificationEventArgs(IMailer mailer, Customer customer, OrderData orderData)
        {
            Mailer = mailer;
            Customer = customer;
            OrderData = orderData;
        }

        public IMailer Mailer { get; set; }
        public Customer Customer { get; set; }
        public OrderData OrderData { get; set; }
    }
}
