using System;
using System.Collections.Generic;
using System.Linq;

namespace Commerce.Engine.Configuration
{
    public class PaymentProcessorElement : ProviderTypeElement
    {
    }
}
