using System;
using System.Collections.Generic;
using System.Linq;

namespace Commerce.Common.Modules
{
    public delegate void CommerceModuleDelegate<T>(T e);
}
