using System;
using System.Collections.Generic;
using System.Linq;

namespace Commerce.Engine.Entities
{
    public class Inventory
    {
        public int Sku { get; set; }
        public int QuantityInStock { get; set; }
    }
}
