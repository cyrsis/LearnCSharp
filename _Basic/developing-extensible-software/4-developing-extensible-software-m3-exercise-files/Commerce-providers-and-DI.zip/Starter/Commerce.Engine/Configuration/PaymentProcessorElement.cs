using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace Commerce.Engine.Configuration
{
    public class PaymentProcessorElement : ProviderTypeElement
    {
        [ConfigurationProperty("loginName", IsRequired = true)]
        public string LoginName
        {
            get { return (string)base["loginName"]; }
            set { base["loginName"] = value; }
        }

        [ConfigurationProperty("password", IsRequired = true)]
        public string Password
        {
            get { return (string)base["password"]; }
            set { base["password"] = value; }
        }
    }
}
